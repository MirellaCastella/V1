const config = {
    db: { /* no exponga la contraseña ni información confidencial, hecho solo para la demostración */
        host: "localhost",
        user: "root",
        password: "",
        database: "baseweb",
    },
    listPerPage: 10,
};

module.exports = config; 