const express = require("express");
const router = express.Router();
const programmingLanguages = require("../services/programmingLanguages");

/* GET programming languages. */

router.get("/", async function(req, res, next) {
    try {
        res.json(await programmingLanguages.getMultiple(req.query.page));
        } catch(err) {
            console.error(`Error al obtener lenguajes de programación`, err.message);
            next(err);
        }
});

/* POST programming language */
router.post("/", async function(req, res, next) {
    try {
      res.json(await programmingLanguages.create(req.body));
      console.log(req.body);
    } catch (err) {
      console.error(`Error al crear el lenguaje de programación`, err.message);
      next(err);
    }
  });

module.exports = router;